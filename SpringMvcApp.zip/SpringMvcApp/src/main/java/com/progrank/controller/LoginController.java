package com.progrank.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.progrank.entities.Courses;
import com.progrank.services.CourseService;

import java.util.*;


@Controller
public class LoginController {
	
	@Autowired
	private CourseService courseService;

	@GetMapping("/login")
	public String login()
	{
		return "login";
	}
	
	@GetMapping("/courses")
	public List<Courses> getCourses()
	{
		return this.courseService.getCourses();
	}
	
	@GetMapping("/courses/{courseId}")
	public Courses getCourses(@PathVariable String courseId)
	{
		return this.courseService.getCourses(Long.parseLong(courseId));
	}
	
	@PostMapping("/Getcourses")
	public Courses addCourses(@RequestBody Courses course)
	{
		return this.courseService.addCourse(course);
	}
}
