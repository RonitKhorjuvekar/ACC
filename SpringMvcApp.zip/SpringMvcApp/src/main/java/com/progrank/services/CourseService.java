package com.progrank.services;

import java.util.List;
import com.progrank.*;
import com.progrank.entities.Courses;

public interface CourseService {
	
	public List<Courses> getCourses();
	
	public Courses getCourses(long courseId);
	
	public Courses addCourse(Courses course);
}
