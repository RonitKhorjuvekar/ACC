package com.progrank.services;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.progrank.entities.Courses;

@Service
public class CourseServiceImpl implements CourseService {

	List<Courses> list;
	
	public CourseServiceImpl()
	{
		list = new ArrayList<>();
		list.add(new Courses(125,"java core","this course"));
		list.add(new Courses(4343,"Spring boot course","create rest api"));
	}
	
	@Override
	public List<Courses> getCourses() {
		// TODO Auto-generated method stub
		return list;
	}

	@Override
	public Courses getCourses(long courseId) {
		// TODO Auto-generated method stub
		Courses c = null;
		
		for(Courses course : list )
		{
			if(course.getId()==courseId)
			{
				c=course;
				break;
			}
		}
		
		return c;
	}

	@Override
	public Courses addCourse(Courses course) {
		// TODO Auto-generated method stub
		list.add(course);
		return course;
	}
	


}
